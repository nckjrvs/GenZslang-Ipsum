import React from 'react';

function Buttion() {
  return <button>Test</button>;
}
